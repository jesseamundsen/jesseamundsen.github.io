function coulomb_series
%   Author:     Jesse Amundsen
%   Date:       03/17/09
%   Contact:    amundsenj1@nku.edu
%   
%   Summary:  This program uses coulomb_approx_values()
%             to attempt to approximate a best-fit
%             linear failure envelope.
%
%   Usage:    The program prompts for input from the user
%             by default. It currently only accepts s3/s1
%             principle stress values rather than normal
%             and shear stress values. It then prompts the
%             user with a question to enter more data or
%             stop and approximate a failure envelope.
%
%   TODO:     - Fix special case where only 1 or 2 stress
%               pairs are entered
%             - Allow for the input of normal and shear
%               stress values alongside principle stress
%               values
%             - Clean up code in this function and in the
%               coulomb_approx_values function

clear
clc

% Set to true so the loop continues
%  on first run and init vars
more_bool = 1;
i = 1;
slope_total = 0;
y_int_total = 0;

% Read input from user to get all data
while more_bool == 1
    s3(i) = input('Sigma 3 Value: ');
    s1(i) = input('Sigma 1 Value: ');
    if i == 1
        biggest_value = s1(i);
    else if s1(i) > (s1(i)-1)
            biggest_value = s1(i);
        end
    end
    i = i+1;
    more_bool = input('More Data? 1 for more, 0 to stop... ');
end

% Now find all combinations of the
%  data points
combinations = combnk(1:i-1,2);

% Then call the value approximation
%  function for each set of combinations
%  NOTE TO SELF: Needs special case for
%                when there are two circles
for j=1:i-1
    % Prepare values for approximation
    s3_comb_1 = s3(combinations(j));
    s1_comb_1 = s1(combinations(j));
    s3_comb_2 = s3(combinations(j,2));
    s1_comb_2 = s1(combinations(j,2));
    % Get a slope and intercept for each combination
    [slope, y_int] = coulomb_approx_values(s3_comb_1, s1_comb_1, ...
        s3_comb_2, s1_comb_2);
    % Save values for average calculation later
    if y_int > 0 && slope > 0
        slope_total = slope_total + slope;
        y_int_total = y_int_total + y_int;
    else
        fprintf('Found a y-int or slope value that is less than zero.\n')
        return
    end
end

% Find the average of each the slope, y_int
%  and the angle of internal friction
slope_avg = slope_total/(i-1);
y_int_avg = y_int_total/(i-1);

% Plot all the Mohr circles
%  and display failure envelope
figure
hold on
x_envelope = 0:1:(biggest_value+biggest_value/4);
y_envelope = slope_avg*x_envelope + y_int_avg;
plot(x_envelope,y_envelope)
for k=1:i-1
    
    % Prevent calculation if k+1 is out of range
    if (k+1) < i
    
        %   Radius of Half-Circles
        r1 = (1/2)*(s1(k)-s3(k));
        r2 = (1/2)*(s1(k+1)-s3(k+1));

        %   Center of Half-Circles
        c1 = s3(k) + r1;
        c2 = s3(k+1) + r2;

        %   Create vectors for Mohr Circles
        for q = 1 : 181
            temp_theta=(q-1)*pi/180;
            HCx1(q) = c1 + r1*cos(temp_theta);
            HCy1(q) = r1*sin(temp_theta);
            HCx2(q) = c2 + r2*cos(temp_theta);
            HCy2(q) = r2*sin(temp_theta);
        end
    
    end
    
    % Plot the two current circles
	plot(HCx1,HCy1,'r')
	plot(HCx2,HCy2,'r')

end

% Pretty up the plot a bit
xlabel('Normal Stress');
ylabel('Shear Stress');
title('Approximate Coulomb Failure Envelope');
grid on;
axis equal;
hold off;

%  calculate phi (angle of internal friction)
phi = asin((y_envelope(3)-y_int_avg)/2)*180/pi;

% Give some output on calculations
fprintf('The approximate Coulomb failure envelope slope is: %6.5f \n', ...
    slope_avg);
fprintf('The approximate cohesion value is: %6.5f (units)\n', ...
    y_int_avg);
fprintf('The angle of internal friction (phi) is: %6.5f (degrees)\n', ...
    phi);

end % End function coulomb_series