function coulomb_approx %[slope, y_int] = coulomb_approx(s3a,s1a,s3b,s1b)

%   Summary:
%   Numerical approximation of the Coulomb Failure Envelope
%   Given two half-circles HC1 and HC2 intersecting the x-axis
%   at [(s3a,0) and (s1a,0)] and [(s3b,0) and (s1b,0)], respectively
%
%   Assumtions:
%       -   [(s1a > s3a) && (s1b > s3b)]
%       -   [(s1a < s1b) && (s3a < s3b)]
%
%   Idealized Situation:
%
%      |                                               
%      |                             .                   
%      |                      .             .            
%      |       .    .    .                     .        
%      |   .            .  .                      .      
%   ======.============.=====.=====================.====
%        s3a          s3b   s1a                   s1b
%      |                                               
%      |                                     , <--- y=(slope)*x + y_int                   
%      |                      ,            
%      |       ,        
%      |         
%   ======.============.=====.=====================.====
%        s3a          s3b   s1a                   s1b

clear
clc

% Temporary values
%s3a = 100; s1a = 200;
%s3b = 300; s1b = 800;
s3a = input('Sigma 3 (Circle A): ');
s1a = input('Sigma 1 (Circle A): ');
s3b = input('Sigma 3 (Circle B): ');
s1b = input('Sigma 1 (Circle B): ');


% Test values
%  note: s3 cannot be larger than s1
if (s1a < s3a || s1b < s3b)
    fprintf('Sigma 3 cannot be larger than Sigma 1\r');
    fprintf('Exiting...\r');
    return;
end
if (s1a > s1b || s3a > s3b)
    fprintf('Second circle must be larger (each s1/s3) than first circle.\r');
    return;
end

%   Radius of Half-Circles
r1 = (1/2)*(s1a-s3a);
r2 = (1/2)*(s1b-s3b);

%   Center of Half-Circles
c1 = s3a + r1;
c2 = s3b + r2;

%   Initialize theta range between 0 and 180 degrees
theta1=0;
theta2=180;

%   Zero in on theta over 10 iterations
for i = 1 : 10
    %   Function "find_theta_range" is located 
    %   at the bottom of this script
    [theta1,theta2] = find_theta_range(theta1, theta2, c1, c2, r1, r2);
end

%   Take average of final theta1 and theta2
theta = (theta1+theta2)/2;

%   Define temp_theta, x1, x2, y1, and y2
temp_theta = theta*pi/180;
x1 = c1 + r1*cos(temp_theta);
y1 = r1*sin(temp_theta);
x2 = c2 + r2*cos(temp_theta);
y2 = r2*sin(temp_theta);

%   Find temporary y-int vector based on current theta
slope = (y2 - y1)/(x2 - x1);
y_int = y1 - x1*slope;

%   Create vector for Failure Envelope
x = 0:s1b/10:s1b;
y = slope*x + y_int;

%   Create vector for Half-Circles
for i = 1 : 181
    temp_theta=(i-1)*pi/180;
    HCx1(i) = c1 + r1*cos(temp_theta);
    HCy1(i) = r1*sin(temp_theta);
    HCx2(i) = c2 + r2*cos(temp_theta);
    HCy2(i) = r2*sin(temp_theta);
end

% Output theta, slope and y-int
fprintf('The Coulomb Failure Envelope slope is: %6.5f \n',slope);
fprintf('The Coulomb Failure Envelope y-int is: %6.5f (units)\n',y_int);
fprintf('The angle (theta) is: %6.5f (degrees)\n',theta);

%   Plot Half-Circles and Coulomb Failure Envelope
figure;
hold on;

plot(HCx1,HCy1,'r');
plot(HCx2,HCy2,'r');
plot(x,y,'b');

xlabel('Normal Stress');
ylabel('Shear Stress');
title('Approximate Coulomb Failure Envelope');
grid on;
axis equal;

x_angle = [2+1*cos(104.47751*pi/180) 6+2*cos(104.47751*pi/180)];
y_angle = [1*sin(104.47751*pi/180) 2*sin(104.47751*pi/180)];
plot([c1 x_angle(1)],[0 y_angle(1)],'g')
plot([c2 x_angle(2)],[0 y_angle(2)],'g')

hold off;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%       BEGIN FUNCTION "FIND_THETA_RANGE"       %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   This function takes in 6 arguements:
%       -   theta1 = The smallest angle in the range for theta
%       -   theta2 = The largest angle in the range for theta
%       -   c1, c2 = The center points for Half-Circles HC1 and HC2 
%       -   r1, r2 = The radii for Half-Circles HC1 and HC2
%
%   Idea behind function:
%       -   The main assumption is that the angle theta, measured from the
%           horizontal (i.e. x-axis), will be the same for both Half-
%           Circles, HC1 and HC2, when the correct tangent line (i.e. 
%           Failure Envelope) is found. The points where this tangent line
%           "touches" the Half-Circles, HC1 and HC2, are (x1,y1) and
%           (x2,y2), respectively.
%
%       -   Therefore, it is the object of this function to: 
%           -   create a vector with a range of angles (i.e. a range 
%               in theta)
%           -   calculate corresponding tangent points on the Half-Circles,
%               HC1 and HC1, (i.e. [x1,y1] and [x2,y2]) for each value of 
%               theta in the defined range
%           -   calculate the corresponding "y-intercept" value 
%               based on the equation for a line going through points 
%               (x1,y1) and (x2,y2) for each value of theta in the defined
%               range
%
%       -   The second assumption is that the "y-intercept" values will be
%           largest around the angle (theta) that exactly corresponds to
%           the "correct" tangent points (i.e. [x1,y1] and [x2,y2]). For 
%           example:
%
%           ^ y-int
%           |
%           |                  
%           |              *       *
%           |         *                 *
%           |     *                         *
%           |  *                               *
%           |*                                    *
%           |=========================================> theta (degrees)
%          0                   ^                     180
%                              |
%                         "Best Theta"
%                              |
%                              v
%           ^ d(y-int)/d(theta)
%           |*
%           |      *                 
%           |           *   
%           |               *
%           |=========================================> theta (degrees)
%           |                     *
%           |                         *
%           |                                *
%           |                                         *
%           v                 
%
%       -   This assumption means that if one were to take the derivative
%           of the "y-int" values with respect to theta, the "correct"
%           value for theta would be where this derivative is equal to 0
%           (zero) or essentially at the greatest "y-int" value. This can 
%           be achieved by:
%           -   explicitly taking the derivative of the equation for 
%               the "y-intercept" with respect to theta, setting it equal
%               to zero and then solving for theta. VERY HARD!
%                                     OR
%           -   numerically calculating the "y-intercept" values for a 
%               range of angles (theta), and then numerically calculating
%               the derivative of the of the "y-intercept" values by:
%
%                     d(f(x))              f(x+DELTAx) - f(x-DELTAx)
%                    -------- (approx. =) --------------------------
%                       dx                        2*DELTAx
%
%               From page 3 (Actually the 11th page in the PDF document) 
%               located at "http://www.imsc.res.in/~rjoy/WWW/research/
%                                   numerics/assets/am585winter06.pdf"
%
%               As expressed in that document, the error in the estimate of
%               df(x)/dx is proportional to the size of DELTAx (i.e. here
%               it is delta_theta), so the smaller the size of DELTAx the
%               smaller the error in your numerical estimate.
%
%               In this situation, one does not necessarily need to
%               compute the derivative in order to find the "best theta".
%               We just need to try to find the closest angle to the "best
%               theta" that gives us the largest "y-int". This is where the
%               power of the computer comes in handy. By giving the
%               computer a range of angles to test, we can find the closest
%               angle by picking the angle that gives us the biggest
%               "y-int".
%
%               To do this, one could simply divide up the range in theta
%               (between 0 and 180 degrees) into, say, 1 million increments
%               such that "delta_theta" would be equal to 180/10^6, compute
%               the values for the "y-intercept" (no need to store them
%               all), and then store the theta that corresponds to the 
%               biggest "y-int" value. The peak "y-int" value would
%               essentially correspond to the angle (theta) that is closest
%               to the "best theta". Depending on how much you divide the
%               range of angles, you can find the most closest angle that
%               will result in the best possible tangent points and, thus,
%               the best possible Failure Envelope.
%                                           OR
%               As in the case of this function, it takes the given range
%               of angles and divides it into 101 increments, and finds the
%               angle that results in the largest "y-int" value, and then
%               returns the two angles that are plus/minus one increment
%               from this best possible angle. By repeating this process,
%               the best possible angle gets narrowed down further and
%               further. This iterative method should also speed up 
%               computation by a couple orders of magnitude compared to 
%               searching over roughly a million different possible values 
%               of theta.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%       BEGIN FUNCTION "FIND_THETA_RANGE"       %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [new_theta1,new_theta2] = ...
                          find_theta_range(theta1, theta2, c1, c2, r1, r2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                      
%   FIND BIGGEST Y-INT VALUE METHOD   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   Define increment in theta
delta_theta = (theta2-theta1)/100;

% Define max_y_int to be very large negative number
max_y_int = -1e6;

%   Loop over all angles in range
%   Exit loop when y-int values start to decrease - it means we have
%   already found the best possible theta for this range/increment.
for i = 1 : 101    
    %   Define temp_theta, x1, x2, y1, and y2
    temp_theta = (theta1+(i-1)*delta_theta)*pi/180;
    x1 = c1 + r1*cos(temp_theta);
    y1 = r1*sin(temp_theta);
    x2 = c2 + r2*cos(temp_theta);
    y2 = r2*sin(temp_theta);
    
    %   Find temporary y-int vector based on current theta
    temp_y_int = y1 - x1*(y2 - y1)/(x2 - x1);
    
    if max_y_int < temp_y_int
        max_y_int = temp_y_int;
        new_theta1=(theta1+(i-2)*delta_theta);
        new_theta2=(theta1+(i)*delta_theta);
    else
        break;
    end
end

return


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                      
%%   COMPUTE NUMERICAL DERIVATIVE METHOD   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% %   Define increment in theta
% delta_theta = (theta2-theta1)/100;
% 
% %   Initialize temporary y-int vector
% %            and theta range vector
% temp_y_int = zeros(1,101);
% theta = theta1 : delta_theta : theta2;
% 
% for i = 1 : 101    
%     %   Define temp_theta, x1, x2, y1, and y2
%     temp_theta = theta(i)*pi/180;
%     x1 = c1 + r1*cos(temp_theta);
%     y1 = r1*sin(temp_theta);
%     x2 = c2 + r2*cos(temp_theta);
%     y2 = r2*sin(temp_theta);
%     
%     %   Find temporary y-int vector based on current theta
%     temp_y_int(i) = y1 - x1*(y2 - y1)/(x2 - x1);
% end
% 
% min_deriv = 1e6;
% min_deriv_index = 0;
% 
% for i = 2 : 100
%     % From page 3 (Actually the 11th page in the PDF document) located at
%     % www.imsc.res.in/~rjoy/WWW/research/numerics/assets/am585winter06.pdf
%     avg_deriv = abs((temp_y_int(i+1) - temp_y_int(i-1))/...
%                            (2*delta_theta));
%     
%     if min_deriv > avg_deriv
%         min_deriv = avg_deriv;
%         min_deriv_index = i;
%     end
% end
% 
% new_theta1 = theta1 + (min_deriv_index-2) * delta_theta;
% new_theta2 = theta1 + (min_deriv_index) * delta_theta;
%
%return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%        END FUNCTION "FIND_THETA_RANGE"        %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%