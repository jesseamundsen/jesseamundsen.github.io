% Function to display SAC data
% by Jesse Amundsen
function display_sac_single


% Get a clean slate
clear
clc

% Determine fmin and fmax for fourier series
%  from user input
fmin = input('Minimum frequency for fourier series: ');
fmax = input('Maximum frequency for fourier series: ');


% Load the SAC data of your choice
%  NOTE: changing the default path is recommended
%        to more easily access the SAC data
[sac_file, sac_path, findex] = uigetfile('/media/sda3/SeismicData/*.sac');
[data,delta,nheader,fid] = load_sac([sac_path, sac_file]);


% Plot data
n_samp=length(data);
time=(delta:delta:(delta*n_samp))';
figure
subplot(2,1,1), plot(time,data)
xlabel('Time')
ylabel('Amplitude')
title('Data')


% Fourier series
%  - define fmin and fmax
%  - define frequency vector
nyq=1/(2*delta);
temp=fft(data);
freq_amp=abs(temp)*(2/n_samp)*(nyq);
freq=(0:length(freq_amp)-1)*((1/delta)-1)/length(freq_amp); 


% Plot fft
%figure
subplot(2,1,2), plot(freq,freq_amp)
set(gca,'XLim',[fmin fmax])
title('Fourier Spectrum')
xlabel('Frequency (Hz)')
ylabel('Amplitude')


% Loads data from an SAC file
%  modified by Jesse Amundsen
%  on 10/08/08
function [data,delta,nheader,fid] = load_sac(name)


filename = name;
[fid,message] = fopen(filename,'r','b');   %unix
%[fid,message] = fopen(filename,'r','l'); %intel


if fid ~= -1
  [fheader,count] = fread(fid,70,'float');
  [nheader,count] = fread(fid,35,'long');
  [lheader,count] = fread(fid,5,'long');
  [kheader,count] = fread(fid,[8,24],'char');


  npts = nheader(10);
  delta = fheader(1);
  date = nheader(1:2);
  hour = nheader(3);
  minu = nheader(4);
  seco = nheader(5) + (nheader(6)/1000);

  data = zeros(npts,1);
  [data,count] = fread(fid,npts,'float');

  
  % added by bodin 19June98 to enable the reading of
  % the file name in the calling routine, it will be
  % called "fname"......
  %  removed 10/08/08 by J. Amundsen, not necessary?
  % fname=filename;


  fclose(fid);
  %clear fheader nheader lheader kheader station
  %clear file path filename fid message count close_stat
  
  
else
  disp(message)
  clear file path filename fid message
end