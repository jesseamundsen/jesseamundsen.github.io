% Function to display SAC data
% by Jesse Amundsen
function display_sac


% Get a clean slate
clear
clc


% Load the SAC data of your choice
%  NOTE: changing the default path is recommended
%        to more easily access the SAC data.
%        currently, it's set to look in specific directories
%        and then find each the e/n/z data for a corresponding
%        set of data
[sac_file, sac_path, findex] = ... 
    uigetfile('/media/sda3/SeismicData/AJJollyEEC/*.sac');

sac_path_e = '/media/sda3/SeismicData/AJJollyEEC/6242e0/';
sac_path_n = '/media/sda3/SeismicData/AJJollyEEC/6242n0/';
sac_path_z = '/media/sda3/SeismicData/AJJollyEEC/6242z0/';

[data_e,delta_e,nheader_e,fid_e] = load_sac([sac_path_e, sac_file]);
[data_n,delta_n,nheader_n,fid_n] = load_sac([sac_path_n, sac_file]);
[data_z,delta_z,nheader_z,fid_z] = load_sac([sac_path_z, sac_file]);


% Plot data for each the e/n/z data all on
%  one figure for simplicity and comparison

% Plot easting data
data = data_e;
delta = delta_e;
n_samp=length(data);
time=(delta:delta:(delta*n_samp))';
figure
ax(1) = subplot(3,1,1);
plot(time,data)
xlabel('Time')
ylabel('Amplitude')
title('Easting','color','b')

% Plot northing data
data = data_n;
delta = delta_n;
n_samp=length(data);
time=(delta:delta:(delta*n_samp))';
ax(2) = subplot(3,1,2);
plot(time,data)
xlabel('Time')
ylabel('Amplitude')
title('Northing','color','b')

% Plot z-data
data = data_z;
delta = delta_z;
n_samp=length(data);
time=(delta:delta:(delta*n_samp))';
ax(3) = subplot(3,1,3);
plot(time,data)
xlabel('Time')
ylabel('Amplitude')
title('Z-Data','color','b')

% Tie the axes together for easier viewing
linkaxes(ax,'xy');


% Loads data from an SAC file
%  modified by Jesse Amundsen
%  on 10/08/08
function [data,delta,nheader,fid] = load_sac(name)


filename = name;
[fid,message] = fopen(filename,'r','b');   %unix
%[fid,message] = fopen(filename,'r','l'); %intel


if fid ~= -1
  [fheader,count] = fread(fid,70,'float');
  [nheader,count] = fread(fid,35,'long');
  [lheader,count] = fread(fid,5,'long');
  [kheader,count] = fread(fid,[8,24],'char');


  npts = nheader(10);
  delta = fheader(1);
  date = nheader(1:2);
  hour = nheader(3);
  minu = nheader(4);
  seco = nheader(5) + (nheader(6)/1000);

  data = zeros(npts,1);
  [data,count] = fread(fid,npts,'float');

  
  % added by bodin 19June98 to enable the reading of
  % the file name in the calling routine, it will be
  % called "fname"......
  %  removed 10/08/08 by J. Amundsen, not necessary?
  % fname=filename;


  fclose(fid);
  %clear fheader nheader lheader kheader station
  %clear file path filename fid message count close_stat
  
  
else
  disp(message)
  clear file path filename fid message
end