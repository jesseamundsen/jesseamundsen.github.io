function boneplot
% BONEPLOT
%  by Jesse Amundsen -- amundsenj1@nku.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%
% CURRENT INPUT FORMAT %
%%%%%%%%%%%%%%%%%%%%%%%%
%   >
%   >   xvar    yvar    zvar    img
%   >
%   - xvar: Value of x-coordinate
%   - yvar: Value of y-coordinate
%   - zvar: Value of z-coordinate
%   -  img: Location to find img (absolute
%           or relative to MATLAB path)
%
% Last Edited: Janurary 09, 2009
%          - Fixed DCM issues with DataIndex
%            by resorting to a brute-force
%            search of the xyz data
%          - Method now allows the user to
%            choose the orthogonal approximation
%            method.
%          - User input to ask whether or not they
%            want to show orthogonal distances.
%          - No longer can select the line vector,
%            plane or orthogonal distance indicators.
%          - File input type now supports data
%            that does not contain an img field
%            for every entry
%
% Purpose: This standalone function reads in
%          data from a file (in a format
%          specified below) that describes
%          the location in 3d space of located
%          fossils. The data is analyzed and
%          a 3d regression model is applied
%          to find the approximate relative dip
%          of all of the data. While previewing,
%          points can be selected and a picture
%          will appear of the fossil found at
%          that given point.
%
%    Note: This function depends on the fit_3d_data()
%          function that approximates regressions for
%          3-dimensional data using orthogonal distance
%          minimization from either a line or a plane.
%          It can make a large difference whether the
%          approximation method is chosen as a line or
%          a plane, consider viewing both and taking
%          into consideration how large of a difference
%          exists and whether the dip values are realistic.

clear
clc

% Determine type of approximation (line or plane),
%  whether or not to show orthogonal distances
%  and prompt for a dataset
reg_type = input('Regression type ("1" - line OR "2" - plane): ');
if reg_type == 1
    approx_type = 'line';
elseif reg_type == 2
    approx_type = 'plane';
else
    disp('Invalid regression type chosen, exiting.')
    return
end
orth_bool = ... 
    input('Show orthogonal distances (0 - no OR 1 - yes): ');
if orth_bool == 0
    orth_type = 'off';
elseif orth_bool == 1
    orth_type = 'on';
else
    disp('Invalid input (must be 0 or 1), exiting.')
    return
end

% Read plaintext file of E N D data.
%  If data has headers, use the provided function below
disp('Choose a dataset to analyze.')
[bone_file, bone_path, bindex] = ... 
    uigetfile('/home/jesse/Documents/MATLAB/data/*.txt');
[xvar yvar zvar img] = textread([bone_path, bone_file], '%f %f %f %s');

% hack in the other data for now
%[xvar2 yvar2 zvar2] = ... 
%    textread('/home/jesse/Documents/MATLAB/data/bonedata-diplodocus.txt');

% Make a new figure, plot the scatter data
%  and then do a 3d fit of the data to get average
%  inclination of samples
plot1 = figure;
%[X1,map1]=imread('Berlin_Diplodocus.jpg');
[X1,map1] = imread('noimg.jpg');
subplot(1,2,1), imshow(X1,map1)
title('Image Preview','color','b');
subplot(1,2,2); 
scatter3(xvar, yvar, zvar, 'filled')
title('3-Dimensional Relative Location of Fossils','color','b');
hold on
[Err,N,P] = fit_3D_data(xvar,yvar,zvar,approx_type,'on',orth_type);
%scatter3(xvar2, yvar2, zvar2, 'r')
axis equal
grid on
xlabel('Easting')
ylabel('Northing')
zlabel('Relative Depth')

% Setup the datacursurmode object
%  to allow user-interaction and displaying
%  of images based on the current data index
%  at a selected point. Must be passed the img
%  data due to scope issues (update function MUST
%  be separate).
datacursormode on
dcm_obj = datacursormode(plot1);
set(dcm_obj,'DisplayStyle','window')
set(dcm_obj,'UpdateFcn',{@bonecursor,xvar,yvar,zvar,img})

% NOTE: Not sure exactly why the approximated
%  dip angle differs depending on the plane/line
%  method. Perhaps a mathematical understanding
%  error. The only difference between the vector
%  from the line method and plane method should
%  be 90degrees (pi/2). It is most likely a difference
%  in the approximation method used by the line/plane
%  case in the fit_3d_data() function. For larger
%  datasets the variance is minimal (1-2% typically
%  for datasets > 100 entries), while for small
%  datasets the results can be dramatically different.
%
% Display approximate dip angle of data. If reg_type
%  is 1, line approximation was chosen. If reg_type
%  is 2, plane approximation was chosen.
%
% For a vector <a,b,c> then:
%  (pi/2) - arccos(c/sqrt(a^2+b^2+c^2))
%
% When using plane approximation, normal vector to the
%  plane will be perpendicular to the plane (another pi/2)
if reg_type == 1
    % To find dip angle of line vector
    %  for vector <a, b, c>
    a = N(1); b = N(2); c = N(3);
    dip_angle = ((pi/2) - acos(c/sqrt((a^2 + b^2 + c^2)))) * (180/pi);
elseif reg_type == 2
    % To find dip angle of line vector
    %  for vector <a, b, c> when fit_3d_data
    %  returns vector perpendicular to plane
    a = N(1); b = N(2); c = N(3);
    dip_angle = ((pi) - acos(c/sqrt((a^2 + b^2 + c^2)))) * (180/pi);
end

% Show dip angle
disp(['Approximated relative dip of dataset: ', ...
    num2str(abs(dip_angle)),' degrees.'])

end %end boneplot

function txt = bonecursor(empt,event_obj,xvar,yvar,zvar,img)
% Display the position of the data cursor
% obj          Currently not used (empty)
% event_obj    Handle to event object
% output_txt   Data cursor text string (string or cell array of strings).

% Notes on getting DCM data
%  and displaying image properly
%  [CODE BELOW]
%  dcm_obj = datacursormode(1)
%  dcm_info = getCursorInfo(dcm_obj);
%  [X1,map1] = imread([num2str(img(dcm_info.DataIndex)),'.jpg'])
%  subplot(1,2,1), imshow(X1,map1);

pos = get(event_obj,'Position');
    txt = {['X: ',num2str(pos(1),4)],...
    ['Y: ',num2str(pos(2),4)]};

% If there is a Z-coordinate in the position, display it as well
if length(pos) > 2
    txt{end+1} = ['Z: ',num2str(pos(3),4)];
end

% Search for the right image to display by brute
%  forcing through the point data; assumes that
%  two points won't be exactly identical.
%
%  NOTE: For some reason, the dcm_obj.DataIndex
%        property returns strange values for the
%        nearest DataIndex so the for loop was
%        chosen instead.
for i = 1 : length(xvar)
    if xvar(i) == pos(1) && ...
            yvar(i) == pos(2) && zvar(i) == pos(3)
        % Check to see if you have img data for this
        %  data point first, if not just display noimg.jpg
        if isempty(img{i})
            [X1,map1] = imread('noimg.jpg');
            subplot(1,2,1), imshow(X1,map1);
            title('Image Preview','color','b');
            return
        end
        [X1,map1] = imread(img{i});
        subplot(1,2,1), imshow(X1,map1);
        title('Image Preview','color','b');
        return % return, no need to look anymore
    end
end

end %end updatefcn