namespace Compress
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.exeButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.exePath = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.compressFiles = new System.Windows.Forms.Button();
            this.fileBrowse = new System.Windows.Forms.Button();
            this.findExe = new System.Windows.Forms.OpenFileDialog();
            this.findFiles = new System.Windows.Forms.OpenFileDialog();
            this.lbFilenames = new System.Windows.Forms.ListBox();
            this.clrItems = new System.Windows.Forms.Button();
            this.folderButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.folderBox = new System.Windows.Forms.TextBox();
            this.findFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.cbCopyFiles = new System.Windows.Forms.CheckBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.status = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.status.SuspendLayout();
            this.SuspendLayout();
            // 
            // exeButton
            // 
            this.exeButton.Location = new System.Drawing.Point(15, 51);
            this.exeButton.Name = "exeButton";
            this.exeButton.Size = new System.Drawing.Size(112, 22);
            this.exeButton.TabIndex = 0;
            this.exeButton.Text = "Browse";
            this.exeButton.UseVisualStyleBackColor = true;
            this.exeButton.Click += new System.EventHandler(this.exeButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Path to your UT3.com";
            // 
            // exePath
            // 
            this.exePath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.exePath.Enabled = false;
            this.exePath.Location = new System.Drawing.Point(15, 25);
            this.exePath.Name = "exePath";
            this.exePath.Size = new System.Drawing.Size(268, 20);
            this.exePath.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Files to be compressed";
            // 
            // compressFiles
            // 
            this.compressFiles.Enabled = false;
            this.compressFiles.Location = new System.Drawing.Point(12, 402);
            this.compressFiles.Name = "compressFiles";
            this.compressFiles.Size = new System.Drawing.Size(112, 23);
            this.compressFiles.TabIndex = 5;
            this.compressFiles.Text = "Compress Files";
            this.compressFiles.UseVisualStyleBackColor = true;
            this.compressFiles.Click += new System.EventHandler(this.compressFiles_Click);
            // 
            // fileBrowse
            // 
            this.fileBrowse.Location = new System.Drawing.Point(16, 233);
            this.fileBrowse.Name = "fileBrowse";
            this.fileBrowse.Size = new System.Drawing.Size(112, 23);
            this.fileBrowse.TabIndex = 6;
            this.fileBrowse.Text = "Find Files";
            this.fileBrowse.UseVisualStyleBackColor = true;
            this.fileBrowse.Click += new System.EventHandler(this.fileBrowse_Click);
            // 
            // findExe
            // 
            this.findExe.Filter = "Command File|*.com|UT3 Executable|UT3.exe";
            this.findExe.Tag = "";
            // 
            // findFiles
            // 
            this.findFiles.Filter = "UT3 Maps (.ut3)|*.ut3|UT3 Mutators (.u)|*.u|UT3 Package (.upk)|*.upk|Other Files " +
                "(.*)|*.*";
            this.findFiles.Multiselect = true;
            // 
            // lbFilenames
            // 
            this.lbFilenames.AllowDrop = true;
            this.lbFilenames.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbFilenames.FormattingEnabled = true;
            this.lbFilenames.HorizontalScrollbar = true;
            this.lbFilenames.Location = new System.Drawing.Point(13, 262);
            this.lbFilenames.Name = "lbFilenames";
            this.lbFilenames.Size = new System.Drawing.Size(475, 132);
            this.lbFilenames.TabIndex = 7;
            // 
            // clrItems
            // 
            this.clrItems.Location = new System.Drawing.Point(130, 233);
            this.clrItems.Name = "clrItems";
            this.clrItems.Size = new System.Drawing.Size(112, 23);
            this.clrItems.TabIndex = 8;
            this.clrItems.Text = "Clear Files";
            this.clrItems.UseVisualStyleBackColor = true;
            this.clrItems.Click += new System.EventHandler(this.clrItems_Click);
            // 
            // folderButton
            // 
            this.folderButton.Location = new System.Drawing.Point(16, 127);
            this.folderButton.Name = "folderButton";
            this.folderButton.Size = new System.Drawing.Size(111, 23);
            this.folderButton.TabIndex = 9;
            this.folderButton.Text = "Choose Folder";
            this.folderButton.UseVisualStyleBackColor = true;
            this.folderButton.Click += new System.EventHandler(this.folderButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(196, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Choose a directory for resulting .uz3 files";
            // 
            // folderBox
            // 
            this.folderBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.folderBox.Enabled = false;
            this.folderBox.Location = new System.Drawing.Point(16, 101);
            this.folderBox.Name = "folderBox";
            this.folderBox.Size = new System.Drawing.Size(267, 20);
            this.folderBox.TabIndex = 11;
            // 
            // cbCopyFiles
            // 
            this.cbCopyFiles.AutoSize = true;
            this.cbCopyFiles.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbCopyFiles.Location = new System.Drawing.Point(185, 408);
            this.cbCopyFiles.Name = "cbCopyFiles";
            this.cbCopyFiles.Size = new System.Drawing.Size(303, 17);
            this.cbCopyFiles.TabIndex = 13;
            this.cbCopyFiles.Text = "Copy files first (solves write issues, will overwrite target files)";
            this.cbCopyFiles.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cbCopyFiles.UseVisualStyleBackColor = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // status
            // 
            this.status.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.status.Location = new System.Drawing.Point(0, 430);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(500, 22);
            this.status.TabIndex = 15;
            this.status.Text = "Created by epitaph";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(98, 17);
            this.toolStripStatusLabel1.Text = "UT3Compress v1.1";
            this.toolStripStatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(100, 17);
            this.toolStripStatusLabel2.Text = "Created by epitaph";
            this.toolStripStatusLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(16, 165);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(146, 17);
            this.radioButton1.TabIndex = 16;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Overwrite files if they exist";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(16, 189);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(122, 17);
            this.radioButton2.TabIndex = 17;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Skip files if they exist";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(500, 452);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.folderBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbCopyFiles);
            this.Controls.Add(this.folderButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.exePath);
            this.Controls.Add(this.clrItems);
            this.Controls.Add(this.lbFilenames);
            this.Controls.Add(this.compressFiles);
            this.Controls.Add(this.fileBrowse);
            this.Controls.Add(this.exeButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.status);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(300, 329);
            this.Name = "Form1";
            this.Text = "UT3Compress";
            this.status.ResumeLayout(false);
            this.status.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exeButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox exePath;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button compressFiles;
        private System.Windows.Forms.Button fileBrowse;
        private System.Windows.Forms.OpenFileDialog findExe;
        private System.Windows.Forms.OpenFileDialog findFiles;
        private System.Windows.Forms.ListBox lbFilenames;
        private System.Windows.Forms.Button clrItems;
        private System.Windows.Forms.Button folderButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox folderBox;
        private System.Windows.Forms.FolderBrowserDialog findFolder;
        private System.Windows.Forms.CheckBox cbCopyFiles;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.StatusStrip status;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
    }
}

