using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace Compress
{
    public partial class Form1 : Form
    {

        //keep track of files
        protected string[] fileList = null;

        //type of file overwrite
        protected bool overwriteRule = true;

        //can we compress yet
        protected bool validExe = false;
        protected bool validFolder = false;
        protected bool validFiles = false;

        //get instance of class
        protected configData cd = new configData();

        public Form1()
        {

            InitializeComponent();

            exePath.Text = cd.exePath;
            findFiles.InitialDirectory = cd.filesPath;
            overwriteRule = Convert.ToBoolean(cd.writeFlag);
            folderBox.Text = cd.outputPath;

            if (exePath.Text != string.Empty)
                validExe = true;
            if (findFiles.InitialDirectory != string.Empty)
                validFolder = true;
            if (folderBox.Text != string.Empty)
                validFiles = true;
            if (overwriteRule == true)
            {
                radioButton1.Checked = true;
            }
            else
            {
                radioButton2.Checked = true;
            }

        }

        private void exeButton_Click(object sender, EventArgs e)
        {

            findExe.InitialDirectory = @"C:\";

            //get the path to the com or exe
            findExe.ShowDialog();
            exePath.Text = findExe.FileName;
            cd.readData();
            cd.exePath = exePath.Text;
            cd.saveData();

            //we have a valid exe
            if (exePath.Text != string.Empty)
                validExe = true;
            else
                validExe = false;

            //check if we can compress
            canCompress();

        }

        private void fileBrowse_Click(object sender, EventArgs e)
        {

            //get the files
            findFiles.ShowDialog();
            fileList = findFiles.FileNames;

            //populate list
            for (int i = 0; i < fileList.Length; i++)
            {
                lbFilenames.Items.Add(fileList[i]);
            }

            string dir = string.Empty;

            if (fileList.Length > 0)
            {
                System.IO.FileInfo fi = new System.IO.FileInfo(fileList[fileList.Length - 1]);
                dir = fi.DirectoryName;
            }

            cd.readData();
            cd.filesPath = dir;
            cd.saveData();

            //we have files now
            if (dir != string.Empty)
                validFiles = true;
            else
                validFiles = false;

            //check if we can compress
            canCompress();

        }

        private void clrItems_Click(object sender, EventArgs e)
        {

            //clear the list
            lbFilenames.Items.Clear();

            //no more files
            validFiles = false;

            //check if we can compress
            canCompress();

        }

        private void canCompress()
        {

            //check if we have required data
            if (validExe == true && validFolder == true && validFiles == true)
                compressFiles.Enabled = true;
            else
                compressFiles.Enabled = false;

        }

        private void compressFiles_Click(object sender, EventArgs e)
        {

            ArrayList copyList = new ArrayList();

            try
            {

                //skip files if they exist
                if (overwriteRule == false)
                {
                    for (int i = 0; i < fileList.Length; i++)
                    {
                        System.IO.FileInfo fi = new System.IO.FileInfo(fileList[i]);
                        string fname = fi.Name;
                        if (!System.IO.File.Exists(folderBox.Text + @"\" + fname + ".uz3"))
                        {
                            copyList.Add(fileList[i]);
                        }
                    }

                    fileList = new string[copyList.Count];

                    for (int i = 0; i < fileList.Length; i++)
                    {
                        fileList[i] = copyList[i].ToString();
                    }

                }

                if (fileList.Length == 0)
                {
                    MessageBox.Show("There are no files to be compressed.");
                }
                else
                {

                    //move files first if checked
                    if (cbCopyFiles.Checked == true)
                    {
                        copyFiles();
                    }

                    //compress all the files in the list
                    compressAll();


                    if (cbCopyFiles.Checked == true)
                    {
                        deleteCopies();
                    }
                    else
                    {
                        //move the compressed files to the chosen folder
                        moveOutput();
                    }


                    //we're done!
                    MessageBox.Show("Compression completed.");

                }

                //clear fileList box to prevent errors
                for (int i = 0; i < fileList.Length; i++)
                {
                    fileList[i] = string.Empty;
                }
                //no longer have valid files
                // can't compress anymore
                // clear the file list
                validFiles = false;
                canCompress();
                lbFilenames.Items.Clear();

            }
            catch (System.IO.FileNotFoundException fex)
            {
                MessageBox.Show("Could not find compressed file to move.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void compressAll()
        {

            //make a string delimited by quotes
            // to pass to the process
            string files = string.Empty;
            for (int i = 0; i < fileList.Length; i++)
            {
                files = files + "\"";
                files = files + fileList[i] + "\" ";
            }

            //shell out and hide the window
            // then compress the files
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo.CreateNoWindow = true;
            proc.StartInfo.UseShellExecute = false;
            proc.EnableRaisingEvents = false;
            proc.StartInfo.FileName="\"" + exePath.Text + "\"";
            proc.StartInfo.Arguments="compress " + files;
            proc.Start();
            proc.WaitForExit();
        }

        private void moveOutput()
        {

            string outputFile = string.Empty;

            for (int i = 0; i < fileList.Length; i++)
            {
                outputFile = fileList[i].Substring(fileList[i].LastIndexOf(@"\") + 1);

                //check if file exists, if yes KILL IT!
                if(System.IO.File.Exists(folderBox.Text + @"\" + outputFile + ".uz3"))
                {
                    System.IO.File.Delete(folderBox.Text + @"\" + outputFile + ".uz3");
                }

                System.IO.File.Move(fileList[i] + ".uz3", folderBox.Text + @"\" + outputFile + ".uz3");
            }
        }

        private void folderButton_Click(object sender, EventArgs e)
        {

            //get the path to the com or exe
            findFolder.ShowDialog();
            folderBox.Text = findFolder.SelectedPath;

            cd.readData();
            cd.outputPath = folderBox.Text;
            cd.saveData();

            //we have a valid exe
            if (folderBox.Text != string.Empty)
                validFolder = true;
            else
                validFolder = false;

            //check if we can compress
            canCompress();

        }

        private void copyFiles()
        {
            
            string outputFile = string.Empty;

            for (int i = 0; i < fileList.Length; i++)
            {
                outputFile = folderBox.Text + @"\" + fileList[i].Substring(fileList[i].LastIndexOf(@"\") + 1);
                System.IO.File.Copy(fileList[i], outputFile, true);
                fileList[i] = outputFile;
            }
            
        }

        private void deleteCopies()
        {
            for (int i = 0; i < fileList.Length; i++)
            {
                System.IO.File.Delete(fileList[i]);
            }
        }

        public class configData
        {
            public string exePath;
            public string outputPath;
            public string writeFlag;
            public string filesPath;

            private string rootLocation = System.Reflection.Assembly.GetExecutingAssembly().Location + ".cfg";

            public configData()
            {

                if (!System.IO.File.Exists(rootLocation))
                {

                    string originalFolder = @"\My Games\Unreal Tournament 3\UTGame\Published\CookedPC\CustomMaps";

                    exePath = @"C:\";
                    outputPath = "";
                    writeFlag = "true";
                    filesPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + originalFolder;
                    saveData();
                }
                else
                {
                    readData();
                }
            }

            public void saveData()
            {
                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(rootLocation))
                {
                    sw.WriteLine(exePath);
                    sw.WriteLine(outputPath);
                    sw.WriteLine(writeFlag);
                    sw.WriteLine(filesPath);
                    sw.Close();
                }
            }

            public void readData()
            {

                

                using (System.IO.StreamReader sr = new System.IO.StreamReader(rootLocation))
                {
                    exePath = sr.ReadLine();
                    outputPath = sr.ReadLine();
                    writeFlag = sr.ReadLine();
                    filesPath = sr.ReadLine();
                    sr.Close();
                }
            }

        }

        //overwrite files
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            overwriteRule = true;
            cd.readData();
            cd.writeFlag = overwriteRule.ToString();
            cd.saveData();
        }

        //skip files
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            overwriteRule = false;
            cd.readData();
            cd.writeFlag = overwriteRule.ToString();
            cd.saveData();
        }

    }
}